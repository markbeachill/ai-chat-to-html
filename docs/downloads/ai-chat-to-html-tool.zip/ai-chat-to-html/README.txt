AI Chat to HTML — the tool
==========================

This is the tool on its own. To use it:

1. Install Python 3 (see https://markbeachill.github.io/ai-chat-to-html/setup.html).
2. In this folder, install the one dependency:
       pip install -r requirements.txt
3. Put your transcript in a file called aichat.txt (or aichat.md), then run:
       python3 aichatprocess.py

You'll get aichat.html and aichat.css. For options (themes, a Word version,
maths), run:
       python3 aichatprocess.py --help

Optional helper: conversation-collector-prompt.md contains a Conversation Collector Prompt that can ask a chatbot to produce a draft aichat.md transcript. Check the result before processing.

Full instructions: https://markbeachill.github.io/ai-chat-to-html/
MIT licensed.
